"""
Indian National Air Quality Index (NAQI) calculator.

Implements the CPCB (Central Pollution Control Board) sub-index method.
Reference: CPCB National Air Quality Index report, 2014.

Overall AQI for a location = MAX sub-index across pollutants ("worst pollutant" rule).

Concentration units (CPCB standard):
    PM2.5, PM10, NO2, SO2, O3, NH3  -> ug/m3
    CO                              -> mg/m3
Averaging periods (respect these with real data):
    PM2.5, PM10, NO2, SO2, NH3, Pb  -> 24-hour average
    CO, O3                          -> 8-hour (max) average
A valid station AQI needs >=3 pollutants incl. PM2.5 or PM10 (see min_pollutants).
"""
from __future__ import annotations

# (C_low, C_high, I_low, I_high) breakpoints per pollutant.
BREAKPOINTS = {
    "PM2.5": [(0,30,0,50),(30,60,51,100),(60,90,101,200),(90,120,201,300),(120,250,301,400),(250,500,401,500)],
    "PM10":  [(0,50,0,50),(50,100,51,100),(100,250,101,200),(250,350,201,300),(350,430,301,400),(430,600,401,500)],
    "NO2":   [(0,40,0,50),(40,80,51,100),(80,180,101,200),(180,280,201,300),(280,400,301,400),(400,1000,401,500)],
    "SO2":   [(0,40,0,50),(40,80,51,100),(80,380,101,200),(380,800,201,300),(800,1600,301,400),(1600,2620,401,500)],
    "CO":    [(0,1.0,0,50),(1.0,2.0,51,100),(2.0,10,101,200),(10,17,201,300),(17,34,301,400),(34,50,401,500)],  # mg/m3
    "O3":    [(0,50,0,50),(50,100,51,100),(100,168,101,200),(168,208,201,300),(208,748,301,400),(748,1000,401,500)],
    "NH3":   [(0,200,0,50),(200,400,51,100),(400,800,101,200),(800,1200,201,300),(1200,1800,301,400),(1800,2400,401,500)],
}

CATEGORIES = [(0,50,"Good"),(51,100,"Satisfactory"),(101,200,"Moderate"),
              (201,300,"Poor"),(301,400,"Very Poor"),(401,500,"Severe")]


def sub_index(pollutant: str, conc):
    """CPCB sub-index for one pollutant concentration (or None)."""
    if conc is None or conc < 0:
        return None
    table = BREAKPOINTS.get(pollutant)
    if table is None:
        return None
    for c_lo, c_hi, i_lo, i_hi in table:
        if c_lo <= conc <= c_hi:
            return i_lo + (i_hi - i_lo) / (c_hi - c_lo) * (conc - c_lo)
    return 500.0  # above top breakpoint -> cap at 500


def category(aqi):
    if aqi is None:
        return "NA"
    for lo, hi, name in CATEGORIES:
        if lo <= aqi <= hi:
            return name
    return "Severe"


def aqi_from_concentrations(conc: dict, min_pollutants: int = 1) -> dict:
    """Overall AQI = max sub-index (worst-pollutant rule)."""
    subs = {p: sub_index(p, v) for p, v in conc.items()}
    subs = {p: s for p, s in subs.items() if s is not None}
    if len(subs) < min_pollutants:
        return {"aqi": None, "category": "NA", "dominant": None, "subindices": subs}
    dominant = max(subs, key=subs.get)
    aqi = round(subs[dominant])
    return {"aqi": aqi, "category": category(aqi), "dominant": dominant, "subindices": subs}


if __name__ == "__main__":
    demo = {"PM2.5": 95, "PM10": 180, "NO2": 45, "SO2": 20, "CO": 1.6, "O3": 70}
    print(aqi_from_concentrations(demo))

"""
ISRO BAH 2026 - PS3, gas fix (1/2): build training table that KEEPS missing
gas readings as NaN (a mask) instead of median-filling them.

Same as 03, but:
  - keeps a row if it has AT LEAST ONE real target (not just PM2.5)
  - does NOT fill missing targets -> they stay NaN so the trainer can ignore them

Output: data/train_masked.npz  (X, Y-with-NaNs, meta)
"""
import numpy as np, pandas as pd, rasterio, os, datetime as dt

GRID_DIR = "data/gee_grid"; LABELS = "data/ground_labels.csv"
OUT = "data/train_masked.npz"
T, K = 5, 5
TARGETS = ["pm25", "no2", "so2", "co", "o3"]
BANDS = ["NO2","SO2","CO","O3","HCHO","AOD","FIRE","T2M","D2M","U10","V10","PRECIP"]

def tif_path_any():
    for f in sorted(os.listdir(GRID_DIR)):
        if f.endswith(".tif"): return os.path.join(GRID_DIR, f)
    raise FileNotFoundError("no tifs")

def load_day(date, pad):
    p = os.path.join(GRID_DIR, f"{date}.tif")
    if not os.path.exists(p): return None
    with rasterio.open(p) as ds:
        a = ds.read().astype("float32")
        if ds.nodata is not None: a[a == ds.nodata] = np.nan
    a[np.abs(a) > 1e30] = np.nan
    return np.pad(a, ((0,0),(pad,pad),(pad,pad)), mode="edge")

df = pd.read_csv(LABELS)
df["date"] = pd.to_datetime(df["date"]).dt.date
df = df.dropna(subset=TARGETS, how="all")          # keep rows with >=1 real target
pad = K // 2

with rasterio.open(tif_path_any()) as ds0:
    def rc(lat, lon): return ds0.index(lon, lat)

cache = {}
def get_day(d):
    if d not in cache: cache[d] = load_day(d, pad)
    return cache[d]

X, Y, meta, skipped = [], [], [], 0
for _, row in df.iterrows():
    d0 = row["date"]
    days = [(d0 - dt.timedelta(days=k)).isoformat() for k in range(T-1, -1, -1)]
    arrs = [get_day(dd) for dd in days]
    if any(a is None for a in arrs): skipped += 1; continue
    r, c = rc(row["lat"], row["lon"]); rp, cp = r+pad, c+pad
    seq = [np.transpose(a[:, rp-pad:rp+pad+1, cp-pad:cp+pad+1], (1,2,0)) for a in arrs]
    X.append(np.stack(seq, 0))
    Y.append([row.get(t, np.nan) for t in TARGETS])    # NaN kept where missing
    meta.append([row["station"], d0.isoformat()])

X = np.asarray(X, "float32"); Y = np.asarray(Y, "float32"); meta = np.asarray(meta)

# fill ONLY predictor gaps (clouds); leave target NaNs alone
for b in range(X.shape[-1]):
    X[..., b] = np.nan_to_num(X[..., b], nan=np.nanmedian(X[..., b]))

np.savez_compressed(OUT, X=X, Y=Y, meta=meta,
                    target_names=np.array(TARGETS), band_names=np.array(BANDS))
print("Saved", OUT)
print("X", X.shape, " Y", Y.shape, " samples", len(X), " skipped", skipped)
realpct = 100*np.mean(~np.isnan(Y), 0)
print("real (non-missing) % per target:", {t: round(p,1) for t,p in zip(TARGETS, realpct)})

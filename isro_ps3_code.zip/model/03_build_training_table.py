"""
ISRO BAH 2026 - PS3, PHASE 2, STEP 1: Build the training table.

For every CPCB label (city, date) we extract from the satellite GeoTIFFs:
  - a KxK spatial PATCH of all 12 bands, centred on the city
  - over the previous T days (so the LSTM sees a time sequence)
That patch-sequence is the INPUT (X); the city's surface pollutants are the TARGET (y).

Output: data/train.npz  with
    X     float32 (N, T, K, K, 12)   model inputs
    Y     float32 (N, 5)             targets [pm25, no2, so2, co, o3]
    meta  (N, 2) strings             [city, date] for traceability
    target_names, band_names

Needs: rasterio, numpy, pandas  (already installed in your Colab).
"""
import numpy as np, pandas as pd, rasterio, os, datetime as dt

GRID_DIR = "data/gee_grid"
LABELS   = "data/ground_labels.csv"
OUT      = "data/train.npz"

T = 5            # days of history per sample (the LSTM time dimension)
K = 5            # patch size KxK (spatial context for the CNN); must be odd
TARGETS = ["pm25", "no2", "so2", "co", "o3"]   # surface values we predict
BANDS = ["NO2","SO2","CO","O3","HCHO","AOD","FIRE","T2M","D2M","U10","V10","PRECIP"]

# ---- helpers ---------------------------------------------------------------
def tif_path(date):
    return os.path.join(GRID_DIR, f"{date}.tif")

def load_day(date, pad):
    """Return an edge-padded (12, H+2pad, W+2pad) array for one day, or None."""
    p = tif_path(date)
    if not os.path.exists(p):
        return None
    with rasterio.open(p) as ds:
        arr = ds.read().astype("float32")               # (12, H, W)
        arr[arr == ds.nodata] = np.nan if ds.nodata is not None else arr
    return np.pad(arr, ((0,0),(pad,pad),(pad,pad)), mode="edge")

def rowcol(lat, lon):
    """Pixel row/col of a lat/lon in the grid (same for every daily tif)."""
    with rasterio.open(tif_path_any()) as ds:
        r, c = ds.index(lon, lat)
    return r, c

def tif_path_any():
    for f in sorted(os.listdir(GRID_DIR)):
        if f.endswith(".tif"):
            return os.path.join(GRID_DIR, f)
    raise FileNotFoundError("No GeoTIFFs in " + GRID_DIR)

# ---- build -----------------------------------------------------------------
df = pd.read_csv(LABELS)
df["date"] = pd.to_datetime(df["date"]).dt.date
df = df.dropna(subset=["pm25"])          # need at least PM2.5 as anchor target
pad = K // 2

# cache padded daily arrays so we only read each tif once
cache = {}
def get_day(date):
    if date not in cache:
        cache[date] = load_day(date, pad)
    return cache[date]

X, Y, meta = [], [], []
skipped = 0
for _, row in df.iterrows():
    d0 = row["date"]
    days = [(d0 - dt.timedelta(days=k)).isoformat() for k in range(T-1, -1, -1)]  # oldest->newest
    arrs = [get_day(dd) for dd in days]
    if any(a is None for a in arrs):     # missing a day in the window
        skipped += 1; continue
    r, c = rowcol(row["lat"], row["lon"])
    rp, cp = r + pad, c + pad            # shift for padding
    seq = []
    for a in arrs:
        patch = a[:, rp-pad:rp+pad+1, cp-pad:cp+pad+1]   # (12, K, K)
        seq.append(np.transpose(patch, (1, 2, 0)))       # (K, K, 12)
    X.append(np.stack(seq, axis=0))                      # (T, K, K, 12)
    Y.append([row.get(t, np.nan) for t in TARGETS])
    meta.append([row["station"], d0.isoformat()])

X = np.asarray(X, dtype="float32")
Y = np.asarray(Y, dtype="float32")
meta = np.asarray(meta)

# fill remaining predictor gaps (clouds) with per-band median
for b in range(X.shape[-1]):
    med = np.nanmedian(X[..., b])
    X[..., b] = np.nan_to_num(X[..., b], nan=med)

# fill missing non-PM targets with column median (PM2.5 already non-null)
for j in range(Y.shape[1]):
    col = Y[:, j]
    med = np.nanmedian(col)
    Y[:, j] = np.where(np.isnan(col), med, col)

np.savez_compressed(OUT, X=X, Y=Y, meta=meta,
                    target_names=np.array(TARGETS), band_names=np.array(BANDS))
print(f"Saved {OUT}")
print(f"  X shape {X.shape}  (samples, days, patch, patch, bands)")
print(f"  Y shape {Y.shape}  targets={TARGETS}")
print(f"  samples kept: {len(X)}   skipped (incomplete window): {skipped}")
print(f"  cities: {len(set(meta[:,0]))}   date span: {meta[:,1].min()} -> {meta[:,1].max()}")

"""
ISRO BAH 2026 - PS3, PHASE 2, STEP 2: Train the CNN-LSTM (Objective 1).

Reads data/train.npz, trains a CNN-LSTM that maps a patch-sequence of
satellite+met bands -> surface pollutant concentrations, and validates on
HELD-OUT CITIES (the real test: can it predict where there is NO monitor?).

Saves:
    models/cnn_lstm.keras     trained model
    models/scalers.npz        normalisation stats (needed for Phase 3 maps)

Needs: tensorflow (preinstalled in Colab), numpy, scikit-learn.
"""
import numpy as np, os
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks
from sklearn.metrics import mean_absolute_error, r2_score

DATA = "data/train.npz"
os.makedirs("models", exist_ok=True)
SEED = 42
np.random.seed(SEED); tf.random.set_seed(SEED)

d = np.load(DATA, allow_pickle=True)
X, Y, meta = d["X"], d["Y"], d["meta"]
TARGETS = list(d["target_names"])
N, T, K, _, C = X.shape
print("X", X.shape, "Y", Y.shape, "targets", TARGETS)

# ---- split by CITY (spatial hold-out) --------------------------------------
cities = np.array(sorted(set(meta[:, 0])))
rng = np.random.default_rng(SEED); rng.shuffle(cities)
n_val = max(3, int(0.25 * len(cities)))
val_cities = set(cities[:n_val])
is_val = np.array([c in val_cities for c in meta[:, 0]])
print(f"{len(cities)} cities -> {n_val} held out for validation: {sorted(val_cities)}")

Xtr, Ytr = X[~is_val], Y[~is_val]
Xva, Yva = X[is_val],  Y[is_val]

# ---- normalise -------------------------------------------------------------
xmean = Xtr.reshape(-1, C).mean(0); xstd = Xtr.reshape(-1, C).std(0) + 1e-6
def nx(a): return (a - xmean) / xstd
ymean = Ytr.mean(0); ystd = Ytr.std(0) + 1e-6
def ny(a): return (a - ymean) / ystd
def iy(a): return a * ystd + ymean        # invert -> real concentrations

Xtr_n, Xva_n = nx(Xtr), nx(Xva)
Ytr_n, Yva_n = ny(Ytr), ny(Yva)

# ---- model -----------------------------------------------------------------
inp = layers.Input((T, K, K, C))
x = layers.TimeDistributed(layers.Conv2D(32, 3, padding="same", activation="relu"))(inp)
x = layers.TimeDistributed(layers.Conv2D(32, 3, padding="same", activation="relu"))(x)
x = layers.TimeDistributed(layers.GlobalAveragePooling2D())(x)   # (T, 32)
x = layers.LSTM(64)(x)
x = layers.Dropout(0.2)(x)
x = layers.Dense(64, activation="relu")(x)
out = layers.Dense(len(TARGETS))(x)
model = models.Model(inp, out)
model.compile(optimizer="adam", loss="mse", metrics=["mae"])
model.summary()

es = callbacks.EarlyStopping(patience=15, restore_best_weights=True, monitor="val_loss")
hist = model.fit(Xtr_n, Ytr_n, validation_data=(Xva_n, Yva_n),
                 epochs=200, batch_size=32, callbacks=[es], verbose=2)

# ---- evaluate on held-out cities (real concentration units) ----------------
pred = iy(model.predict(Xva_n, verbose=0))
pred = np.clip(pred, 0, None)
print("\n=== Validation on held-out cities (real units) ===")
for j, t in enumerate(TARGETS):
    mae = mean_absolute_error(Yva[:, j], pred[:, j])
    r2  = r2_score(Yva[:, j], pred[:, j])
    print(f"  {t:5s}  MAE={mae:8.2f}   R2={r2:6.3f}")
print("  (PM2.5 is the most reliable metric; other targets had some imputed values.)")

model.save("models/cnn_lstm.keras")
np.savez("models/scalers.npz", xmean=xmean, xstd=xstd, ymean=ymean, ystd=ystd,
         target_names=np.array(TARGETS))
print("\nSaved models/cnn_lstm.keras and models/scalers.npz")

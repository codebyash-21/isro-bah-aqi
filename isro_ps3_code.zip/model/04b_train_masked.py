"""
ISRO BAH 2026 - PS3, gas fix (2/2): train the CNN-LSTM with a MASKED loss so
missing gas readings are ignored. The model only learns from, and is scored on,
REAL CPCB measurements.

Reads data/train_masked.npz. Saves models/cnn_lstm_masked.keras + scalers_masked.npz.
"""
import numpy as np, os
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks
from sklearn.metrics import mean_absolute_error, r2_score

d = np.load("data/train_masked.npz", allow_pickle=True)
X, Y, meta = d["X"], d["Y"], d["meta"]
TARGETS = list(d["target_names"]); N, T, K, _, C = X.shape
os.makedirs("models", exist_ok=True)
SEED = 42; np.random.seed(SEED); tf.random.set_seed(SEED)
print("X", X.shape, "Y", Y.shape)

# split by city (spatial hold-out)
cities = np.array(sorted(set(meta[:,0])))
rng = np.random.default_rng(SEED); rng.shuffle(cities)
val_cities = set(cities[:max(3, int(0.25*len(cities)))])
is_val = np.array([c in val_cities for c in meta[:,0]])
print("held-out cities:", sorted(val_cities))
Xtr, Ytr, Xva, Yva = X[~is_val], Y[~is_val], X[is_val], Y[is_val]

# normalise X (per band) and Y (per target, NaN-aware)
xmean = Xtr.reshape(-1,C).mean(0); xstd = Xtr.reshape(-1,C).std(0)+1e-6
nx = lambda a: (a - xmean)/xstd
ymean = np.nanmean(Ytr,0); ystd = np.nanstd(Ytr,0)+1e-6
ny = lambda a: (a - ymean)/ystd
iy = lambda a: a*ystd + ymean
Xtr_n, Xva_n = nx(Xtr), nx(Xva)
Ytr_n, Yva_n = ny(Ytr), ny(Yva)            # NaNs preserved

# masked MSE: ignore NaN targets
def masked_mse(y_true, y_pred):
    mask = tf.cast(~tf.math.is_nan(y_true), tf.float32)
    y0 = tf.where(tf.math.is_nan(y_true), tf.zeros_like(y_true), y_true)
    se = tf.square(y_pred - y0) * mask
    return tf.reduce_sum(se) / (tf.reduce_sum(mask) + 1e-6)

inp = layers.Input((T,K,K,C))
x = layers.TimeDistributed(layers.Conv2D(32,3,padding="same",activation="relu"))(inp)
x = layers.TimeDistributed(layers.Conv2D(32,3,padding="same",activation="relu"))(x)
x = layers.TimeDistributed(layers.GlobalAveragePooling2D())(x)
x = layers.LSTM(64)(x); x = layers.Dropout(0.2)(x)
x = layers.Dense(64, activation="relu")(x)
out = layers.Dense(len(TARGETS))(x)
model = models.Model(inp, out)
model.compile(optimizer="adam", loss=masked_mse)

es = callbacks.EarlyStopping(patience=15, restore_best_weights=True, monitor="val_loss")
model.fit(Xtr_n, Ytr_n, validation_data=(Xva_n, Yva_n),
          epochs=200, batch_size=32, callbacks=[es], verbose=2)

# evaluate per pollutant on REAL held-out values only
pred = np.clip(iy(model.predict(Xva_n, verbose=0)), 0, None)
print("\n=== Validation on held-out cities (real values only) ===")
for j, t in enumerate(TARGETS):
    yt = Yva[:, j]; m = ~np.isnan(yt)
    if m.sum() < 5: print(f"  {t:5s}  (too few real values)"); continue
    print(f"  {t:5s}  n={int(m.sum()):4d}  MAE={mean_absolute_error(yt[m], pred[m,j]):8.2f}"
          f"  R2={r2_score(yt[m], pred[m,j]):6.3f}")

model.save("models/cnn_lstm_masked.keras")
np.savez("models/scalers_masked.npz", xmean=xmean, xstd=xstd, ymean=ymean, ystd=ystd,
         target_names=np.array(TARGETS))
print("\nSaved models/cnn_lstm_masked.keras + scalers_masked.npz")

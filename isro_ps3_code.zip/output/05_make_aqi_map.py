"""
ISRO BAH 2026 - PS3, PHASE 3, STEP 1: National surface-AQI heatmap (Objective 1).

Runs the trained CNN-LSTM over EVERY grid cell in India for one date, converts
the predicted pollutants to CPCB AQI, and renders a heatmap over the country.

Output: output/aqi_map_<DATE>.png   and   output/aqi_grid_<DATE>.npy

Needs: tensorflow, numpy, rasterio, matplotlib.
"""
import numpy as np, rasterio, os, datetime as dt
import tensorflow as tf
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap
from numpy.lib.stride_tricks import sliding_window_view

GRID_DIR = "data/gee_grid"
DATE = "2019-11-08"      # a peak-burning day; change to any date you downloaded
T, K = 5, 5
EXTENT = [68.0, 98.0, 8.0, 37.0]     # lon_min, lon_max, lat_min, lat_max
os.makedirs("output", exist_ok=True)

# ---- CPCB AQI from the 5 predicted pollutants (vectorised) -----------------
IP = [0, 50, 100, 200, 300, 400, 500]
CP = {  # concentration breakpoints (CO in mg/m3, rest ug/m3)
 "pm25":[0,30,60,90,120,250,500], "no2":[0,40,80,180,280,400,1000],
 "so2":[0,40,80,380,800,1600,2620], "co":[0,1,2,10,17,34,50],
 "o3":[0,50,100,168,208,748,1000]}
def aqi_from(pred, names):
    subs = [np.interp(pred[..., j], CP[t], IP) for j, t in enumerate(names)]
    return np.max(np.stack(subs, -1), -1)     # worst-pollutant rule

# ---- load model + scalers --------------------------------------------------
model = tf.keras.models.load_model("models/cnn_lstm.keras")
s = np.load("models/scalers.npz", allow_pickle=True)
xmean, xstd, ymean, ystd = s["xmean"], s["xstd"], s["ymean"], s["ystd"]
TARGETS = list(s["target_names"])

# ---- build the patch-sequence for every pixel ------------------------------
def day_array(date):
    p = os.path.join(GRID_DIR, f"{date}.tif")
    with rasterio.open(p) as ds:
        a = ds.read().astype("float32")           # (C, H, W)
        if ds.nodata is not None: a[a == ds.nodata] = np.nan
    return a

d0 = dt.date.fromisoformat(DATE)
days = [(d0 - dt.timedelta(days=k)).isoformat() for k in range(T-1, -1, -1)]
stack = [day_array(dd) for dd in days]            # list of (C,H,W)
C, H, W = stack[0].shape
pad = K // 2

seq = np.empty((H*W, T, K, K, C), dtype="float32")
for ti, a in enumerate(stack):
    a = np.transpose(a, (1, 2, 0))                # (H, W, C)
    a = np.pad(a, ((pad,pad),(pad,pad),(0,0)), mode="edge")
    win = sliding_window_view(a, (K, K), axis=(0, 1))  # (H, W, C, K, K)
    win = np.transpose(win, (0, 1, 3, 4, 2)).reshape(H*W, K, K, C)
    seq[:, ti] = win

# normalise (NaN -> mean -> 0 after z-score)
seq = (seq - xmean) / xstd
seq = np.nan_to_num(seq, nan=0.0)

# ---- predict over the whole grid -------------------------------------------
pred = model.predict(seq, batch_size=2048, verbose=1)
pred = pred * ystd + ymean
pred = np.clip(pred, 0, None)
aqi = aqi_from(pred, TARGETS).reshape(H, W)
np.save(f"output/aqi_grid_{DATE}.npy", aqi)

# ---- plot ------------------------------------------------------------------
bounds = [0, 50, 100, 200, 300, 400, 500]
colors = ["#2ECC71", "#F1C40F", "#E67E22", "#E74C3C", "#8E44AD", "#7B241C"]
cmap = ListedColormap(colors); norm = BoundaryNorm(bounds, cmap.N)

plt.figure(figsize=(8, 9))
im = plt.imshow(aqi, extent=EXTENT, origin="upper", cmap=cmap, norm=norm)
cbar = plt.colorbar(im, ticks=[25,75,150,250,350,450], shrink=0.8)
cbar.ax.set_yticklabels(["Good","Satisf.","Moderate","Poor","Very Poor","Severe"])
plt.title(f"Predicted Surface AQI over India - {DATE}\nCNN-LSTM from satellite + meteorology")
plt.xlabel("Longitude"); plt.ylabel("Latitude")
plt.tight_layout()
plt.savefig(f"output/aqi_map_{DATE}.png", dpi=150)
print("Saved output/aqi_map_%s.png" % DATE)
print("AQI range:", int(np.nanmin(aqi)), "-", int(np.nanmax(aqi)),
      " mean:", int(np.nanmean(aqi)))

"""
ISRO BAH 2026 - PS3: build a DATE-SELECTABLE static web app.

Runs the masked model for every date in the season, saves a land-masked AQI
overlay per date, samples city AQI per date, and generates a single-folder
website (Leaflet + a date slider). No server needed.

Output folder: output/web/
    index.html            <- open this / deploy this folder
    overlays/<date>.png   <- per-date AQI layers
The whole 'web' folder can be opened locally OR hosted on GitHub Pages / Netlify.
"""
import numpy as np, rasterio, os, json, datetime as dt, io, base64
import tensorflow as tf
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap
from numpy.lib.stride_tricks import sliding_window_view
import pandas as pd
from global_land_mask import globe

GRID_DIR="data/gee_grid"; T,K=5,5
EXTENT=[68.0,98.0,8.0,37.0]
STRIDE=2                       # every 2nd day (set 1 for every day, slower)
START,END=dt.date(2019,10,1),dt.date(2020,3,1)
WEB="output/web"; os.makedirs(WEB+"/overlays",exist_ok=True)

IP=[0,50,100,200,300,400,500]
CP={"pm25":[0,30,60,90,120,250,500],"no2":[0,40,80,180,280,400,1000],
    "so2":[0,40,80,380,800,1600,2620],"o3":[0,50,100,168,208,748,1000]}
AQI_TARGETS=["pm25","no2","so2","o3"]

model=tf.keras.models.load_model("models/cnn_lstm_masked.keras",compile=False)
s=np.load("models/scalers_masked.npz",allow_pickle=True)
xmean,xstd,ymean,ystd=s["xmean"],s["xstd"],s["ymean"],s["ystd"]; TARGETS=list(s["target_names"])

def read(date):
    p=os.path.join(GRID_DIR,f"{date}.tif")
    if not os.path.exists(p): return None
    with rasterio.open(p) as ds:
        a=ds.read().astype("float32")
        if ds.nodata is not None: a[a==ds.nodata]=np.nan
    a[np.abs(a)>1e30]=np.nan; return a

cache={}; d=START
while d<END: cache[d.isoformat()]=read(d.isoformat()); d+=dt.timedelta(days=1)

# grid geometry + land mask
H=W=None
for v in cache.values():
    if v is not None: _,H,W=v.shape; break
lats=EXTENT[3]-(np.arange(H)+0.5)*(EXTENT[3]-EXTENT[2])/H
lons=EXTENT[0]+(np.arange(W)+0.5)*(EXTENT[1]-EXTENT[0])/W
lon2d,lat2d=np.meshgrid(lons,lats); land=globe.is_land(lat2d,lon2d)

bounds=[0,50,100,200,300,400,500]
colors=["#2ECC71","#F1C40F","#E67E22","#E74C3C","#8E44AD","#7B241C"]
cmap=ListedColormap(colors); norm=BoundaryNorm(bounds,cmap.N)

def aqi_for(date):
    days=[(dt.date.fromisoformat(date)-dt.timedelta(days=k)).isoformat() for k in range(T-1,-1,-1)]
    if any(cache.get(dd) is None for dd in days): return None
    pad=K//2; seq=np.empty((H*W,T,K,K,12),dtype="float32")
    for ti,dd in enumerate(days):
        a=np.transpose(cache[dd],(1,2,0)); a=np.pad(a,((pad,pad),(pad,pad),(0,0)),mode="edge")
        win=sliding_window_view(a,(K,K),axis=(0,1))
        seq[:,ti]=np.transpose(win,(0,1,3,4,2)).reshape(H*W,K,K,12)
    seq=np.nan_to_num((seq-xmean)/xstd,nan=0.0)
    pred=np.clip(model.predict(seq,batch_size=4096,verbose=0)*ystd+ymean,0,None)
    subs=[np.interp(pred[:,TARGETS.index(t)],CP[t],IP) for t in AQI_TARGETS]
    return np.max(np.stack(subs,-1),-1).reshape(H,W)

cities=pd.read_csv("data/ground_labels.csv")[["station","lat","lon"]].drop_duplicates()
def grid_val(g,lat,lon):
    r=min(max(int((EXTENT[3]-lat)/(EXTENT[3]-EXTENT[2])*H),0),H-1)
    c=min(max(int((lon-EXTENT[0])/(EXTENT[1]-EXTENT[0])*W),0),W-1)
    return float(g[r,c])

dates=[]; d=START+dt.timedelta(days=T-1)
while d<END: dates.append(d.isoformat()); d+=dt.timedelta(days=STRIDE)

out_dates=[]; city_aqi={}; fires={}; hcho_pts={}; overlays_uri={}
for dte in dates:
    g=aqi_for(dte)
    if g is None: continue
    rgba=cmap(norm(g)); rgba[...,3]=np.where(land,1.0,0.0)
    buf=io.BytesIO(); plt.imsave(buf,rgba,format="png")
    overlays_uri[dte]="data:image/png;base64,"+base64.b64encode(buf.getvalue()).decode()
    city_aqi[dte]={r["station"]:round(grid_val(g,r["lat"],r["lon"])) for _,r in cities.iterrows()}
    a=cache[dte]; fire=a[6]; hch=a[4]
    fr,fc=np.where((np.nan_to_num(fire)>0)&land)
    fires[dte]=[[round(float(lats[r]),3),round(float(lons[c]),3)] for r,c in zip(fr,fc)]
    thr=np.nanmean(hch)+2*np.nanstd(hch)
    hr,hc=np.where((hch>thr)&land)
    hcho_pts[dte]=[[round(float(lats[r]),3),round(float(lons[c]),3)] for r,c in zip(hr,hc)]
    out_dates.append(dte)
print("built",len(out_dates),"dates")

DATA={"dates":out_dates,"bounds":[[EXTENT[2],EXTENT[0]],[EXTENT[3],EXTENT[1]]],
      "overlays":overlays_uri,
      "cities":[{"name":r["station"],"lat":r["lat"],"lon":r["lon"]} for _,r in cities.iterrows()],
      "city_aqi":city_aqi,"fires":fires,"hcho":hcho_pts}

LEGEND=("<b>Predicted AQI</b><br>"
 "<span class=sw style='background:#2ECC71'></span>Good<br>"
 "<span class=sw style='background:#F1C40F'></span>Satisfactory<br>"
 "<span class=sw style='background:#E67E22'></span>Moderate<br>"
 "<span class=sw style='background:#E74C3C'></span>Poor<br>"
 "<span class=sw style='background:#8E44AD'></span>Very Poor<br>"
 "<span class=sw style='background:#7B241C'></span>Severe")

HTML=r"""<!DOCTYPE html><html><head><meta charset="utf-8">
<title>India Surface AQI — ISRO BAH 2026</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
 body{margin:0;font-family:Arial,sans-serif}#map{height:100vh}
 #panel{position:absolute;top:10px;left:60px;z-index:1000;background:#fff;padding:12px 16px;border-radius:8px;box-shadow:0 1px 6px rgba(0,0,0,.3);max-width:340px}
 #legend{position:absolute;bottom:24px;left:12px;z-index:1000;background:#fff;padding:10px;border-radius:8px;font-size:12px;box-shadow:0 1px 6px rgba(0,0,0,.3)}
 .sw{display:inline-block;width:12px;height:12px;margin-right:5px;border:1px solid #999}
 input[type=range]{width:300px}#datelbl{font-weight:bold;color:#b00}
</style></head><body>
<div id="map"></div>
<div id="panel">
 <b>Predicted Surface AQI over India</b><br>
 <small>CNN-LSTM from satellite + meteorology · ISRO BAH 2026</small><br><br>
 Date: <span id="datelbl"></span><br>
 <input type="range" id="slider" min="0" value="0"/><br>
 <small>Drag the slider to change the date. Click any city dot for its AQI and health advisory.</small>
</div>
<div id="legend">__LEGEND__</div>
<script>
const DATA=__DATA__;
const map=L.map('map').setView([23,80],5);
L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
 {attribution:'&copy; OpenStreetMap &copy; CARTO'}).addTo(map);
function adv(a){
 if(a<=50)return["Good","Minimal impact. Air is clean.","#2ECC71"];
 if(a<=100)return["Satisfactory","Minor breathing discomfort to sensitive people.","#F1C40F"];
 if(a<=200)return["Moderate","Discomfort to people with lung/heart disease, children and older adults.","#E67E22"];
 if(a<=300)return["Poor","Breathing discomfort to most people on prolonged exposure.","#E74C3C"];
 if(a<=400)return["Very Poor","Respiratory illness on prolonged exposure. Avoid outdoor activity.","#8E44AD"];
 return["Severe","Serious health risk. Stay indoors.","#7B241C"];}

// layers
let aqiLayer=L.imageOverlay(DATA.overlays[DATA.dates[0]],DATA.bounds,{opacity:0.5}).addTo(map);
let fireLayer=L.layerGroup();
let hchoLayer=L.layerGroup();
let cityLayer=L.layerGroup().addTo(map);
const markers={};
DATA.cities.forEach(c=>{markers[c.name]=L.circleMarker([c.lat,c.lon],
 {radius:7,color:'#333',weight:1,fillOpacity:0.9}).addTo(cityLayer);});
L.control.layers(null,{
 "Predicted Surface AQI":aqiLayer,
 "Active fires":fireLayer,
 "HCHO hotspots":hchoLayer,
 "City AQI + advisory":cityLayer},{collapsed:false}).addTo(map);

const slider=document.getElementById('slider');slider.max=DATA.dates.length-1;
function render(i){const d=DATA.dates[i];document.getElementById('datelbl').textContent=d;
 aqiLayer.setUrl(DATA.overlays[d]);
 DATA.cities.forEach(c=>{const a=DATA.city_aqi[d][c.name];const v=adv(a);
  markers[c.name].setStyle({fillColor:v[2]});
  markers[c.name].bindPopup('<b>'+c.name+'</b><br>AQI ~ '+Math.round(a)+' ('+v[0]+')<br><i>'+v[1]+'</i>');});
 fireLayer.clearLayers();
 (DATA.fires[d]||[]).forEach(p=>L.circleMarker(p,{radius:2,color:'black',fillOpacity:0.7}).addTo(fireLayer));
 hchoLayer.clearLayers();
 (DATA.hcho[d]||[]).forEach(p=>L.circleMarker(p,{radius:3,color:'purple',weight:1,fillOpacity:0.5}).addTo(hchoLayer));}
slider.addEventListener('input',e=>render(+e.target.value));render(0);
</script></body></html>"""

html=HTML.replace("__DATA__",json.dumps(DATA)).replace("__LEGEND__",LEGEND)
open(f"{WEB}/index.html","w").write(html)
print("Saved",WEB+"/index.html  — open it, or deploy the whole 'web' folder")

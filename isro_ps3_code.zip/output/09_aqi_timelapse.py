"""
ISRO BAH 2026 - PS3, FEATURE 1: seasonal AQI time-lapse animation.

Runs the masked model over the whole India grid for many dates across the
2019-20 burning season and assembles them into an animated GIF, so you can
WATCH pollution build and move with the stubble-burning season.

Output: output/aqi_timelapse.gif
        output/aqi_frames/<date>.png   (individual frames, reused by dashboard)
"""
import numpy as np, rasterio, os, glob, datetime as dt
import tensorflow as tf
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap
import matplotlib.animation as animation
from numpy.lib.stride_tricks import sliding_window_view

GRID_DIR = "data/gee_grid"; T, K = 5, 5
EXTENT = [68.0, 98.0, 8.0, 37.0]
STRIDE = 3                       # render every 3rd day (faster). set 1 for every day
START, END = dt.date(2019,10,1), dt.date(2020,3,1)
os.makedirs("output/aqi_frames", exist_ok=True)

IP=[0,50,100,200,300,400,500]
CP={"pm25":[0,30,60,90,120,250,500],"no2":[0,40,80,180,280,400,1000],
    "so2":[0,40,80,380,800,1600,2620],"o3":[0,50,100,168,208,748,1000]}
AQI_TARGETS=["pm25","no2","so2","o3"]

model = tf.keras.models.load_model("models/cnn_lstm_masked.keras", compile=False)
s = np.load("models/scalers_masked.npz", allow_pickle=True)
xmean,xstd,ymean,ystd = s["xmean"],s["xstd"],s["ymean"],s["ystd"]
TARGETS=list(s["target_names"])

# cache every season day's raster
def read(date):
    p=os.path.join(GRID_DIR,f"{date}.tif")
    if not os.path.exists(p): return None
    with rasterio.open(p) as ds:
        a=ds.read().astype("float32")
        if ds.nodata is not None: a[a==ds.nodata]=np.nan
    a[np.abs(a)>1e30]=np.nan
    return a

cache={}
d=START
while d<END:
    cache[d.isoformat()]=read(d.isoformat()); d+=dt.timedelta(days=1)

def aqi_for(date):
    days=[(dt.date.fromisoformat(date)-dt.timedelta(days=k)).isoformat() for k in range(T-1,-1,-1)]
    if any(cache.get(dd) is None for dd in days): return None
    C,H,W=cache[days[0]].shape; pad=K//2
    seq=np.empty((H*W,T,K,K,C),dtype="float32")
    for ti,dd in enumerate(days):
        a=np.transpose(cache[dd],(1,2,0))
        a=np.pad(a,((pad,pad),(pad,pad),(0,0)),mode="edge")
        win=sliding_window_view(a,(K,K),axis=(0,1))
        seq[:,ti]=np.transpose(win,(0,1,3,4,2)).reshape(H*W,K,K,C)
    seq=np.nan_to_num((seq-xmean)/xstd,nan=0.0)
    pred=np.clip(model.predict(seq,batch_size=4096,verbose=0)*ystd+ymean,0,None)
    subs=[np.interp(pred[:,TARGETS.index(t)],CP[t],IP) for t in AQI_TARGETS]
    return np.max(np.stack(subs,-1),-1).reshape(H,W)

# build frames
dates=[]
d=START+dt.timedelta(days=T-1)
while d<END:
    dates.append(d.isoformat()); d+=dt.timedelta(days=STRIDE)

bounds=[0,50,100,200,300,400,500]
colors=["#2ECC71","#F1C40F","#E67E22","#E74C3C","#8E44AD","#7B241C"]
cmap=ListedColormap(colors); norm=BoundaryNorm(bounds,cmap.N)

grids=[]; labels=[]
for dte in dates:
    g=aqi_for(dte)
    if g is None: continue
    grids.append(g); labels.append(dte)
    plt.imsave(f"output/aqi_frames/{dte}.png", g, cmap=cmap, vmin=0, vmax=500)
print(f"computed {len(grids)} frames")

fig,ax=plt.subplots(figsize=(7,8))
im=ax.imshow(grids[0],extent=EXTENT,origin="upper",cmap=cmap,norm=norm)
cb=fig.colorbar(im,ticks=[25,75,150,250,350,450],shrink=0.8)
cb.ax.set_yticklabels(["Good","Satisf.","Moderate","Poor","V.Poor","Severe"])
ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
ttl=ax.set_title("")
def upd(i):
    im.set_data(grids[i]); ttl.set_text(f"Predicted Surface AQI over India — {labels[i]}")
    return im,ttl
ani=animation.FuncAnimation(fig,upd,frames=len(grids),interval=300)
ani.save("output/aqi_timelapse.gif",writer=animation.PillowWriter(fps=4))
print("Saved output/aqi_timelapse.gif")

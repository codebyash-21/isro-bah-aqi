"""
ISRO BAH 2026 - PS3, FEATURES 2 & 3: interactive dashboard + health advisory.
Now LAND-MASKED: AQI and hotspots only shown over land (ocean values from
satellite retrievals are noise and were cluttering the sea).

Setup (run once in Colab):  !pip install global-land-mask -q

Output: output/aqi_dashboard.html
"""
import numpy as np, rasterio, os, folium, pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap
from global_land_mask import globe

DATE="2019-11-08"; GRID_DIR="data/gee_grid"
EXTENT=[68.0,98.0,8.0,37.0]; B={"HCHO":4,"FIRE":6}
ALPHA=0.45   # AQI layer opacity: lower=more see-through (try 0.25-0.6)
os.makedirs("output",exist_ok=True)

npy=f"output/aqi_grid_masked_{DATE}.npy"
assert os.path.exists(npy), f"Run 05b_make_aqi_map_masked.py first to create {npy}"
aqi=np.load(npy); H,W=aqi.shape

# ---- land mask for the grid ------------------------------------------------
lats=EXTENT[3]-(np.arange(H)+0.5)*(EXTENT[3]-EXTENT[2])/H
lons=EXTENT[0]+(np.arange(W)+0.5)*(EXTENT[1]-EXTENT[0])/W
lon2d,lat2d=np.meshgrid(lons,lats)
land=globe.is_land(lat2d,lon2d)

def advisory(a):
    if a<=50:  return "Good","Minimal impact. Air is clean.","#2ECC71"
    if a<=100: return "Satisfactory","Minor breathing discomfort to sensitive people.","#F1C40F"
    if a<=200: return "Moderate","Breathing discomfort to people with lung/heart disease, children and older adults.","#E67E22"
    if a<=300: return "Poor","Breathing discomfort to most people on prolonged exposure.","#E74C3C"
    if a<=400: return "Very Poor","Respiratory illness on prolonged exposure. Avoid outdoor activity.","#8E44AD"
    return "Severe","Affects healthy people; serious risk for those with existing conditions. Stay indoors.","#7B241C"

# ---- AQI overlay (transparent over ocean) ----------------------------------
bounds=[0,50,100,200,300,400,500]
colors=["#2ECC71","#F1C40F","#E67E22","#E74C3C","#8E44AD","#7B241C"]
cmap=ListedColormap(colors); norm=BoundaryNorm(bounds,cmap.N)
rgba=cmap(norm(aqi))
rgba[...,3]=np.where(land,1.0,0.0)          # land opaque, ocean transparent

m=folium.Map(location=[23,80],zoom_start=5,tiles="cartodbpositron")
# pass the array directly -> folium embeds it as base64 INSIDE the html
folium.raster_layers.ImageOverlay(name="Predicted Surface AQI",
    image=rgba,
    bounds=[[EXTENT[2],EXTENT[0]],[EXTENT[3],EXTENT[1]]],
    opacity=ALPHA,interactive=False).add_to(m)   # <-- translucency knob

with rasterio.open(os.path.join(GRID_DIR,f"{DATE}.tif")) as ds:
    a=ds.read().astype("float32")
    if ds.nodata is not None: a[a==ds.nodata]=np.nan
a[np.abs(a)>1e30]=np.nan
fire=a[B["FIRE"]]; hcho=a[B["HCHO"]]

def cell_lonlat(r,c):
    return (EXTENT[3]-(r+0.5)*(EXTENT[3]-EXTENT[2])/H,
            EXTENT[0]+(c+0.5)*(EXTENT[1]-EXTENT[0])/W)

fg_fire=folium.FeatureGroup(name="Active fires",show=False)
for r,c in zip(*np.where(np.nan_to_num(fire)>0)):
    if not land[r,c]: continue
    lat,lon=cell_lonlat(r,c)
    folium.CircleMarker([lat,lon],radius=2,color="black",fill=True,fill_opacity=0.7).add_to(fg_fire)
fg_fire.add_to(m)

thr=np.nanmean(hcho)+2*np.nanstd(hcho)
fg_h=folium.FeatureGroup(name="HCHO hotspots",show=False)
for r,c in zip(*np.where(hcho>thr)):
    if not land[r,c]: continue                  # land only
    lat,lon=cell_lonlat(r,c)
    folium.CircleMarker([lat,lon],radius=3,color="purple",fill=True,fill_opacity=0.5).add_to(fg_h)
fg_h.add_to(m)

cities=pd.read_csv("data/ground_labels.csv")[["station","lat","lon"]].drop_duplicates()
def grid_aqi(lat,lon):
    r=min(max(int((EXTENT[3]-lat)/(EXTENT[3]-EXTENT[2])*H),0),H-1)
    c=min(max(int((lon-EXTENT[0])/(EXTENT[1]-EXTENT[0])*W),0),W-1)
    return float(aqi[r,c])
fg_city=folium.FeatureGroup(name="City AQI + advisory",show=True)
for _,row in cities.iterrows():
    a_=grid_aqi(row["lat"],row["lon"]); cat,adv,col=advisory(a_)
    html=f"<b>{row['station']}</b><br>AQI ~ {int(a_)} ({cat})<br><i>{adv}</i>"
    folium.CircleMarker([row["lat"],row["lon"]],radius=7,color=col,fill=True,
        fill_color=col,fill_opacity=0.9,popup=folium.Popup(html,max_width=250)).add_to(fg_city)
fg_city.add_to(m)

legend=("<div style='position:fixed;bottom:30px;left:30px;z-index:9999;background:white;"
        "padding:10px;border:1px solid grey;font-size:12px'><b>Predicted AQI</b><br>"
        "<span style='color:#2ECC71'>&#9632;</span> Good 0-50<br>"
        "<span style='color:#F1C40F'>&#9632;</span> Satisfactory 51-100<br>"
        "<span style='color:#E67E22'>&#9632;</span> Moderate 101-200<br>"
        "<span style='color:#E74C3C'>&#9632;</span> Poor 201-300<br>"
        "<span style='color:#8E44AD'>&#9632;</span> Very Poor 301-400<br>"
        "<span style='color:#7B241C'>&#9632;</span> Severe 401-500<br>"
        f"<br><b>Date:</b> {DATE}</div>")
m.get_root().html.add_child(folium.Element(legend))
folium.LayerControl().add_to(m)
m.save("output/aqi_dashboard.html")
print("Saved output/aqi_dashboard.html (land-masked)")

"""
ISRO BAH 2026 - PS3, PHASE 3, STEP 2: HCHO hotspots + fire + wind (Objective 2).

Reads the HCHO, FIRE and wind (U10/V10) bands straight from the GeoTIFFs
(no model needed), flags HCHO hotspots as statistical anomalies, overlays
active fires and wind vectors, and shows the burning -> formaldehyde link.

Outputs:
    output/hcho_hotspots_<DATE>.png    map: HCHO + hotspots + fires + wind
    output/hcho_fire_corr.png          HCHO vs fire-count relationship
"""
import numpy as np, rasterio, os, glob, datetime as dt
import matplotlib.pyplot as plt

GRID_DIR = "data/gee_grid"
DATE = "2019-11-08"
EXTENT = [68.0, 98.0, 8.0, 37.0]
# band order in the GeoTIFF
B = {"NO2":0,"SO2":1,"CO":2,"O3":3,"HCHO":4,"AOD":5,"FIRE":6,
     "T2M":7,"D2M":8,"U10":9,"V10":10,"PRECIP":11}
os.makedirs("output", exist_ok=True)

def read(date):
    with rasterio.open(os.path.join(GRID_DIR, f"{date}.tif")) as ds:
        a = ds.read().astype("float32")
        if ds.nodata is not None: a[a == ds.nodata] = np.nan
    return a

a = read(DATE)
hcho = a[B["HCHO"]]; fire = a[B["FIRE"]]
u = a[B["U10"]]; v = a[B["V10"]]
H, W = hcho.shape

# ---- hotspot detection: HCHO above mean + 2*std (per-scene anomaly) ---------
mu, sd = np.nanmean(hcho), np.nanstd(hcho)
thresh = mu + 2*sd
hot = hcho > thresh
print(f"HCHO threshold (mean+2sd) = {thresh:.3e} mol/m^2; hotspot cells = {int(np.nansum(hot))}")

# ---- map -------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 9))
im = ax.imshow(hcho, extent=EXTENT, origin="upper", cmap="YlOrRd")
plt.colorbar(im, ax=ax, shrink=0.8, label="HCHO column (mol/m$^2$)")

# hotspot outlines
ax.contour(hot.astype(float), levels=[0.5], colors="purple", linewidths=1.2,
           extent=EXTENT, origin="upper")

# active fires (FIRE band > 0) as points
yy, xx = np.where(fire > 0)
lon = EXTENT[0] + (xx + 0.5) * (EXTENT[1]-EXTENT[0]) / W
lat = EXTENT[3] - (yy + 0.5) * (EXTENT[3]-EXTENT[2]) / H
ax.scatter(lon, lat, s=6, c="black", marker="x", label="active fire", alpha=0.6)

# wind vectors (subsampled) -> shows transport direction
step = 8
Y, X = np.mgrid[0:H:step, 0:W:step]
glon = EXTENT[0] + (X + 0.5) * (EXTENT[1]-EXTENT[0]) / W
glat = EXTENT[3] - (Y + 0.5) * (EXTENT[3]-EXTENT[2]) / H
ax.quiver(glon, glat, u[::step, ::step], v[::step, ::step],
          color="steelblue", scale=200, width=0.002, alpha=0.7)

ax.set_title(f"HCHO Hotspots, Fires & Wind Transport - {DATE}\n"
             "purple = hotspot outline, x = fire, arrows = wind")
ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
ax.legend(loc="lower left", fontsize=8)
plt.tight_layout(); plt.savefig(f"output/hcho_hotspots_{DATE}.png", dpi=150)
print("Saved output/hcho_hotspots_%s.png" % DATE)

# ---- HCHO vs fire relationship across the whole season ---------------------
hv, fv = [], []
for f in sorted(glob.glob(os.path.join(GRID_DIR, "*.tif"))):
    arr = read(os.path.splitext(os.path.basename(f))[0])
    hv.append(np.nanmean(arr[B["HCHO"]]))
    fv.append(np.nansum(arr[B["FIRE"]] > 0))
hv, fv = np.array(hv), np.array(fv)
if len(hv) > 2 and np.nanstd(fv) > 0:
    r = np.corrcoef(fv, hv)[0, 1]
else:
    r = float("nan")
plt.figure(figsize=(6,5))
plt.scatter(fv, hv, c="firebrick")
plt.xlabel("Active-fire cell count (per day)")
plt.ylabel("Mean HCHO column (mol/m$^2$)")
plt.title(f"HCHO vs fire activity over India\nPearson r = {r:.2f}")
plt.tight_layout(); plt.savefig("output/hcho_fire_corr.png", dpi=150)
print(f"Saved output/hcho_fire_corr.png  (HCHO-fire correlation r = {r:.2f})")

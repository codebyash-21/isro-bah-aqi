"""
ISRO BAH 2026 - PS3, PHASE 3 (refined): proper fire -> HCHO link (Objective 2).

Yesterday's flat r = -0.01 compared a NATIONAL daily average of HCHO to a
national fire count - too coarse. The real fire->formaldehyde signal is:
  (a) LOCAL  - it shows up in the same/neighbouring cells, not nationwide
  (b) LAGGED - HCHO forms a day or two AFTER the fire, downwind
This script measures it correctly and produces three clear results.

Outputs:
    output/fire_hcho_lag.png        mean local correlation vs lag (0-3 days)
    output/fire_hcho_corrmap.png    where the fire->HCHO link is strongest
    output/fire_hcho_compare.png    HCHO over high-fire vs no-fire cells
"""
import numpy as np, rasterio, os, glob, datetime as dt
import matplotlib.pyplot as plt

GRID = "data/gee_grid"
EXTENT = [68.0, 98.0, 8.0, 37.0]
B = {"HCHO": 4, "FIRE": 6}
START, END = dt.date(2019, 10, 1), dt.date(2020, 3, 1)   # season only (skip stray 2024 tifs)
os.makedirs("output", exist_ok=True)

# ---- load the season's HCHO and fire stacks --------------------------------
files = []
for f in sorted(glob.glob(os.path.join(GRID, "*.tif"))):
    name = os.path.splitext(os.path.basename(f))[0]
    try:
        d = dt.date.fromisoformat(name)
    except ValueError:
        continue
    if START <= d < END:
        files.append((d, f))
files.sort()
print(f"Using {len(files)} daily files from {files[0][0]} to {files[-1][0]}")

hcho, fire = [], []
for d, f in files:
    with rasterio.open(f) as ds:
        a = ds.read().astype("float32")
        if ds.nodata is not None:
            a[a == ds.nodata] = np.nan
    a[np.abs(a) > 1e30] = np.nan          # kill float32-max no-data sentinels
    hcho.append(a[B["HCHO"]])
    fire.append((np.nan_to_num(a[B["FIRE"]], nan=0.0) > 0).astype("float32"))  # fire presence
hcho = np.array(hcho); fire = np.array(fire)             # (T, H, W)
T, H, W = hcho.shape

# fill HCHO cloud gaps with each day's spatial median so corr is defined
for t in range(T):
    m = np.nanmedian(hcho[t])
    hcho[t] = np.nan_to_num(hcho[t], nan=m)

def pearson_axis0(x, y):
    xm = x - x.mean(0); ym = y - y.mean(0)
    num = (xm * ym).sum(0)
    den = np.sqrt((xm**2).sum(0) * (ym**2).sum(0)) + 1e-9
    return num / den

# only analyse cells that actually saw fire (>=3 fire-days over the season)
fire_season = fire.sum(0)
active = fire_season >= 3
print(f"fire-active cells: {int(active.sum())}")

# ---- (1) correlation vs lag -------------------------------------------------
lags = [0, 1, 2, 3]
mean_corr = []
for lag in lags:
    f = fire if lag == 0 else fire[:-lag]
    h = hcho if lag == 0 else hcho[lag:]
    c = pearson_axis0(f, h)
    mean_corr.append(float(np.nanmean(c[active])))
best = int(np.argmax(mean_corr))
print("mean local corr by lag:", {l: round(c,3) for l,c in zip(lags, mean_corr)})
print(f"strongest at lag = {lags[best]} day(s), r = {mean_corr[best]:.3f}")

plt.figure(figsize=(6,4))
plt.plot(lags, mean_corr, "o-", color="firebrick")
plt.axhline(0, color="gray", lw=0.8)
plt.xlabel("Lag (days HCHO after fire)"); plt.ylabel("Mean local correlation")
plt.title("Fire -> HCHO link strengthens with a 1-2 day lag")
plt.tight_layout(); plt.savefig("output/fire_hcho_lag.png", dpi=150)

# ---- (2) correlation map at the best lag -----------------------------------
lag = lags[best]
f = fire if lag == 0 else fire[:-lag]
h = hcho if lag == 0 else hcho[lag:]
cmap_corr = pearson_axis0(f, h)
cmap_corr[~active] = np.nan
plt.figure(figsize=(8,9))
im = plt.imshow(cmap_corr, extent=EXTENT, origin="upper", cmap="RdBu_r",
                vmin=-1, vmax=1)
plt.colorbar(im, shrink=0.8, label=f"fire->HCHO correlation (lag {lag}d)")
plt.title(f"Where burning drives formaldehyde (lag {lag} day)\n"
          "red = strong positive fire->HCHO link")
plt.xlabel("Longitude"); plt.ylabel("Latitude")
plt.tight_layout(); plt.savefig("output/fire_hcho_corrmap.png", dpi=150)

# ---- (3) HCHO over high-fire vs no-fire cells ------------------------------
hcho_mean = np.nanmean(hcho, 0)
hi = fire_season >= np.percentile(fire_season[fire_season > 0], 90) if (fire_season>0).any() else active
lo = fire_season == 0
print(f"mean HCHO  high-fire cells = {np.nanmean(hcho_mean[hi]):.3e}   "
      f"no-fire cells = {np.nanmean(hcho_mean[lo]):.3e}")
plt.figure(figsize=(6,5))
plt.boxplot([hcho_mean[lo][~np.isnan(hcho_mean[lo])],
             hcho_mean[hi][~np.isnan(hcho_mean[hi])]],
            labels=["No-fire cells", "High-fire cells"], showfliers=False)
plt.ylabel("Seasonal mean HCHO column (mol/m$^2$)")
plt.title("Formaldehyde is higher where fires burn")
plt.tight_layout(); plt.savefig("output/fire_hcho_compare.png", dpi=150)
print("Saved 3 figures to output/")

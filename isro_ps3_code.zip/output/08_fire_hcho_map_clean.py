"""
ISRO BAH 2026 - PS3: presentation-ready fire->HCHO correlation map (Objective 2).
Re-reads the season, computes the lag-1 fire->HCHO correlation, and draws a
clean, zoomed map of the north-India burning belt with labelled regions.

Output: output/fire_hcho_map_clean.png
"""
import numpy as np, rasterio, os, glob, datetime as dt
import matplotlib.pyplot as plt

GRID = "data/gee_grid"
EXTENT = [68.0, 98.0, 8.0, 37.0]
B = {"HCHO": 4, "FIRE": 6}
START, END = dt.date(2019, 10, 1), dt.date(2020, 3, 1)
LAG = 1                      # peak lag found in step 07
os.makedirs("output", exist_ok=True)

# ---- load season HCHO + fire (with no-data handling) -----------------------
files = []
for f in sorted(glob.glob(os.path.join(GRID, "*.tif"))):
    n = os.path.splitext(os.path.basename(f))[0]
    try: d = dt.date.fromisoformat(n)
    except ValueError: continue
    if START <= d < END: files.append((d, f))
files.sort()

hcho, fire = [], []
for d, f in files:
    with rasterio.open(f) as ds:
        a = ds.read().astype("float32")
        if ds.nodata is not None: a[a == ds.nodata] = np.nan
    a[np.abs(a) > 1e30] = np.nan
    hcho.append(a[B["HCHO"]])
    fire.append((np.nan_to_num(a[B["FIRE"]], nan=0.0) > 0).astype("float32"))
hcho = np.array(hcho); fire = np.array(fire)
T, H, W = hcho.shape
for t in range(T):
    hcho[t] = np.nan_to_num(hcho[t], nan=np.nanmedian(hcho[t]))

# ---- lag-1 correlation on fire-active cells --------------------------------
def pearson0(x, y):
    xm = x - x.mean(0); ym = y - y.mean(0)
    return (xm*ym).sum(0) / (np.sqrt((xm**2).sum(0)*(ym**2).sum(0)) + 1e-9)

fseason = fire.sum(0)
active = fseason >= 3
c = pearson0(fire[:-LAG], hcho[LAG:])

# ---- cell centre lon/lat of active cells -----------------------------------
rows, cols = np.where(active)
lon = EXTENT[0] + (cols + 0.5) * (EXTENT[1]-EXTENT[0]) / W
lat = EXTENT[3] - (rows + 0.5) * (EXTENT[3]-EXTENT[2]) / H
corr = c[rows, cols]

# ---- plot ------------------------------------------------------------------
hcho_bg = np.nanmean(hcho, 0)
fig, ax = plt.subplots(figsize=(9, 8))
# faint HCHO context background
ax.imshow(hcho_bg, extent=EXTENT, origin="upper", cmap="Greys", alpha=0.25)
# fire-active cells coloured by fire->HCHO correlation
sc = ax.scatter(lon, lat, c=corr, cmap="RdBu_r", vmin=-0.4, vmax=0.4,
                s=120, edgecolor="k", linewidth=0.4)
cb = fig.colorbar(sc, ax=ax, shrink=0.8)
cb.set_label(f"fire → HCHO correlation (lag {LAG} day)")

# zoom to the action (north India)
ax.set_xlim(68, 90); ax.set_ylim(20, 33)
ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
ax.set_title("Where crop burning drives formaldehyde (lag 1 day)\n"
             "fire-active cells, 2019–20 season  |  red = strong fire→HCHO link")

# region annotations
ax.annotate("Punjab–Haryana\nstubble-burning belt", xy=(75.5, 30.3),
            xytext=(70.5, 31.6), fontsize=10, color="darkred",
            arrowprops=dict(arrowstyle="->", color="darkred"))
ax.plot(77.2, 28.6, "k^", ms=7); ax.text(77.5, 28.4, "Delhi", fontsize=9)
ax.grid(alpha=0.2)
plt.tight_layout(); plt.savefig("output/fire_hcho_map_clean.png", dpi=160)
print("Saved output/fire_hcho_map_clean.png")
print(f"active cells={int(active.sum())}, mean corr (lag {LAG})={np.nanmean(corr):.3f}")

"""
ISRO BAH 2026 - PS3: national AQI map using the improved MASKED model,
with the unreliable CO dropped from the AQI composite.

Output: output/aqi_map_masked_<DATE>.png
"""
import numpy as np, rasterio, os, datetime as dt
import tensorflow as tf
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap
from numpy.lib.stride_tricks import sliding_window_view

GRID_DIR = "data/gee_grid"; DATE = "2019-11-08"; T, K = 5, 5
EXTENT = [68.0, 98.0, 8.0, 37.0]
os.makedirs("output", exist_ok=True)

# AQI from predicted pollutants (CO intentionally excluded)
IP = [0,50,100,200,300,400,500]
CP = {"pm25":[0,30,60,90,120,250,500], "no2":[0,40,80,180,280,400,1000],
      "so2":[0,40,80,380,800,1600,2620], "o3":[0,50,100,168,208,748,1000]}
AQI_TARGETS = ["pm25","no2","so2","o3"]      # no CO

model = tf.keras.models.load_model("models/cnn_lstm_masked.keras",
                                   safe_mode=False, compile=False)
s = np.load("models/scalers_masked.npz", allow_pickle=True)
xmean,xstd,ymean,ystd = s["xmean"],s["xstd"],s["ymean"],s["ystd"]
TARGETS = list(s["target_names"])

def day_array(date):
    with rasterio.open(os.path.join(GRID_DIR, f"{date}.tif")) as ds:
        a = ds.read().astype("float32")
        if ds.nodata is not None: a[a==ds.nodata]=np.nan
    a[np.abs(a)>1e30]=np.nan
    return a

d0 = dt.date.fromisoformat(DATE)
days = [(d0-dt.timedelta(days=k)).isoformat() for k in range(T-1,-1,-1)]
stack = [day_array(dd) for dd in days]
C,H,W = stack[0].shape; pad = K//2
seq = np.empty((H*W,T,K,K,C),dtype="float32")
for ti,a in enumerate(stack):
    a = np.transpose(a,(1,2,0))
    a = np.pad(a,((pad,pad),(pad,pad),(0,0)),mode="edge")
    win = sliding_window_view(a,(K,K),axis=(0,1))
    seq[:,ti] = np.transpose(win,(0,1,3,4,2)).reshape(H*W,K,K,C)
seq = np.nan_to_num((seq-xmean)/xstd, nan=0.0)

pred = np.clip(model.predict(seq,batch_size=2048,verbose=1)*ystd+ymean, 0, None)
# build AQI from the 4 reliable pollutants
subs = []
for t in AQI_TARGETS:
    j = TARGETS.index(t)
    subs.append(np.interp(pred[:,j], CP[t], IP))
aqi = np.max(np.stack(subs,-1),-1).reshape(H,W)
np.save(f"output/aqi_grid_masked_{DATE}.npy", aqi)

bounds=[0,50,100,200,300,400,500]
colors=["#2ECC71","#F1C40F","#E67E22","#E74C3C","#8E44AD","#7B241C"]
cmap=ListedColormap(colors); norm=BoundaryNorm(bounds,cmap.N)
plt.figure(figsize=(8,9))
im=plt.imshow(aqi,extent=EXTENT,origin="upper",cmap=cmap,norm=norm)
cb=plt.colorbar(im,ticks=[25,75,150,250,350,450],shrink=0.8)
cb.ax.set_yticklabels(["Good","Satisf.","Moderate","Poor","Very Poor","Severe"])
plt.title(f"Predicted Surface AQI over India - {DATE}\n"
          "CNN-LSTM (masked model; PM2.5/NO2/SO2/O3)")
plt.xlabel("Longitude"); plt.ylabel("Latitude")
plt.tight_layout(); plt.savefig(f"output/aqi_map_masked_{DATE}.png",dpi=150)
print("Saved output/aqi_map_masked_%s.png"%DATE)
print("AQI range",int(np.nanmin(aqi)),"-",int(np.nanmax(aqi)),"mean",int(np.nanmean(aqi)))

"""
ISRO BAH 2026 - Problem Statement 3
PHASE 1, STEP 1: Pull all gridded satellite + fire + meteorology predictors
from Google Earth Engine as daily, multi-band GeoTIFFs over an India grid.

RUN THIS IN GOOGLE COLAB (easiest) or any machine with the Earth Engine
Python API authenticated.

What it produces:
    data/gee_grid/YYYY-MM-DD.tif   (one multi-band GeoTIFF per day)
    Bands, in order:
        0 NO2     - tropospheric NO2 column        (mol/m^2)
        1 SO2     - SO2 column                      (mol/m^2)
        2 CO      - CO column                       (mol/m^2)
        3 O3      - O3 column                       (mol/m^2)
        4 HCHO    - tropospheric HCHO column        (mol/m^2)   <-- Obj 2
        5 AOD     - MODIS MAIAC AOD @550nm          (unitless, x0.001 applied)
        6 FIRE    - active-fire brightness T21      (Kelvin; proxy for fire) <-- Obj 2
        7 T2M     - 2 m air temperature             (K)
        8 D2M     - 2 m dewpoint temperature        (K)  -> RH computed later
        9 U10     - 10 m wind, eastward             (m/s)
       10 V10     - 10 m wind, northward            (m/s)
       11 PRECIP  - total precipitation (daily sum) (m)

These 12 bands are your model INPUT channels. Surface AQI labels come from
the separate script 02_fetch_ground_openaq.py (CPCB via OpenAQ).
"""

# ----------------------------------------------------------------------
# 0. SETUP  (in Colab, run these once)
#    !pip install geemap earthengine-api -q
# ----------------------------------------------------------------------
import ee, geemap, os, datetime as dt

# Put YOUR Earth Engine cloud project id here (from console.cloud.google.com)
EE_PROJECT = "your-ee-project-id"      # <<< EDIT THIS

ee.Authenticate()                       # opens a browser / pastes a token
ee.Initialize(project=EE_PROJECT)

# ----------------------------------------------------------------------
# 1. CONFIG  -- start SMALL, then widen once it works
# ----------------------------------------------------------------------
# India bounding box (lon_min, lat_min, lon_max, lat_max)
REGION = ee.Geometry.Rectangle([68.0, 8.0, 98.0, 37.0])

START = "2024-10-15"      # crop-burning season; widen to full Oct-Feb later
END   = "2024-11-15"      # END is exclusive
SCALE = 27830             # ~0.25 deg in metres. Use 11132 for ~0.1 deg (heavier)

OUT_DIR = "data/gee_grid"
os.makedirs(OUT_DIR, exist_ok=True)

# ----------------------------------------------------------------------
# 2. DAILY COMPOSITE BUILDERS
#    Each returns a single-band ee.Image (daily mean over the region),
#    cloud-masked where a cloud band exists.
# ----------------------------------------------------------------------
def _s5p(collection, band, d0, d1, cloud_max=0.5):
    sel = [band] + (["cloud_fraction"] if cloud_max is not None else [])
    col = (ee.ImageCollection(collection)
             .filterDate(d0, d1)
             .filterBounds(REGION)
             .select(sel))
    def mask(img):
        if cloud_max is not None:
            img = img.updateMask(img.select("cloud_fraction").lt(cloud_max))
        return img.select(band)
    return col.map(mask).mean().rename(band)

def daily_image(date):
    d0 = ee.Date(date)
    d1 = d0.advance(1, "day")

    no2  = _s5p("COPERNICUS/S5P/OFFL/L3_NO2",  "tropospheric_NO2_column_number_density",  d0, d1).rename("NO2")
    so2  = _s5p("COPERNICUS/S5P/OFFL/L3_SO2",  "SO2_column_number_density",               d0, d1).rename("SO2")
    co   = _s5p("COPERNICUS/S5P/OFFL/L3_CO",   "CO_column_number_density",                d0, d1, cloud_max=None).rename("CO")
    o3   = _s5p("COPERNICUS/S5P/OFFL/L3_O3",   "O3_column_number_density",                d0, d1, cloud_max=None).rename("O3")
    hcho = _s5p("COPERNICUS/S5P/OFFL/L3_HCHO", "tropospheric_HCHO_column_number_density", d0, d1).rename("HCHO")

    # MODIS MAIAC AOD @ 550 nm (multiple granules/day -> mean). scale factor 0.001.
    aod = (ee.ImageCollection("MODIS/061/MCD19A2_GRANULES")
             .filterDate(d0, d1).filterBounds(REGION)
             .select("Optical_Depth_055").mean().multiply(0.001).rename("AOD"))

    # FIRMS active fire brightness (T21). unmask 0 so "no fire" = 0, not masked.
    fire = (ee.ImageCollection("FIRMS")
              .filterDate(d0, d1).filterBounds(REGION)
              .select("T21").max().unmask(0).rename("FIRE"))

    # ERA5-Land daily aggregate meteorology
    era = ee.ImageCollection("ECMWF/ERA5_LAND/DAILY_AGGR").filterDate(d0, d1).filterBounds(REGION).first()
    t2m    = era.select("temperature_2m").rename("T2M")
    d2m    = era.select("dewpoint_temperature_2m").rename("D2M")
    u10    = era.select("u_component_of_wind_10m").rename("U10")
    v10    = era.select("v_component_of_wind_10m").rename("V10")
    precip = era.select("total_precipitation_sum").rename("PRECIP")

    img = (no2.addBands([so2, co, o3, hcho, aod, fire, t2m, d2m, u10, v10, precip])
              .toFloat().clip(REGION))
    return img

# ----------------------------------------------------------------------
# 3. LOOP OVER DAYS AND DOWNLOAD
# ----------------------------------------------------------------------
def daterange(start, end):
    d = dt.date.fromisoformat(start)
    last = dt.date.fromisoformat(end)
    while d < last:
        yield d.isoformat()
        d += dt.timedelta(days=1)

if __name__ == "__main__":
    for date in daterange(START, END):
        out = os.path.join(OUT_DIR, f"{date}.tif")
        if os.path.exists(out):
            print("skip (exists):", date); continue
        try:
            img = daily_image(date)
            # Direct download (fine for a 0.25-deg India grid: tiny file).
            geemap.ee_export_image(img, filename=out, scale=SCALE,
                                   region=REGION, file_per_band=False)
            print("ok  :", date)
        except Exception as e:
            print("FAIL:", date, "->", repr(e))

    print("\nDone. GeoTIFFs in:", OUT_DIR)
    print("Inspect one with:  import rasterio; rasterio.open('<file>').read().shape")

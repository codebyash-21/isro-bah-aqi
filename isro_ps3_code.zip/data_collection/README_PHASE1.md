# Phase 1 — Data Collection (ISRO BAH 2026, PS3)

Goal of this phase: produce two things, both on the **same India grid and time window**:

1. **Predictors** — daily multi-band GeoTIFFs of satellite columns + AOD + fire + meteorology
   → `data/gee_grid/YYYY-MM-DD.tif`  (12 bands, from `01_extract_gee.py`)
2. **Labels** — CPCB surface concentrations at monitoring stations
   → `data/ground_labels.csv`  (from `02_fetch_ground_openaq.py`)

In Phase 2 you join these: features come from the GeoTIFF cell (and its neighbours,
over the last N days) at each station's location; the label is that station's CPCB reading.

---

## Before you run anything (day-one checklist)

- [ ] **Earth Engine**: create a free Cloud project, enable the Earth Engine API,
      note the project id. Put it in `01_extract_gee.py` → `EE_PROJECT`.
- [ ] **OpenAQ**: sign up at openaq.org, create an API key. Put it in
      `02_fetch_ground_openaq.py` → `OPENAQ_KEY`.
- [ ] (Optional, later) **MOSDAC** account for INSAT-3D AOD, **CDS** for ERA5 single-levels
      if you want boundary-layer height. Not needed to get started — MODIS AOD and
      ERA5-Land already come through GEE.

## Recommended environment

**Google Colab.** No local install pain, and Earth Engine auth is one line.
At the top of a Colab cell:

```python
!pip install geemap earthengine-api rasterio requests -q
```

Then paste/run `01_extract_gee.py`, then `02_fetch_ground_openaq.py`.

---

## Run order

1. **`01_extract_gee.py`** — edit `EE_PROJECT`, keep the default short window
   (2024-10-15 → 2024-11-15) for the first run. It downloads ~31 GeoTIFFs.
   Verify it worked:

   ```python
   import rasterio, glob
   f = sorted(glob.glob("data/gee_grid/*.tif"))[0]
   ds = rasterio.open(f)
   print(ds.count, "bands", ds.shape, ds.descriptions)   # expect 12 bands, ~(116,120)
   ```

2. **`02_fetch_ground_openaq.py`** — edit `OPENAQ_KEY`, same window. Produces
   `data/ground_labels.csv`. Open it and confirm you have rows with lat/lon and
   pollutant columns populated.

3. **Once both look right**, widen `START`/`END` to the full burning season
   (e.g. 2024-10-01 → 2025-02-28) and re-run. The scripts skip days already
   downloaded, so re-running is cheap.

---

## What each band/column is for

| Source | Fields | Role |
|---|---|---|
| Sentinel-5P TROPOMI | NO2, SO2, CO, O3, HCHO | model inputs; HCHO also drives Obj 2 |
| MODIS MAIAC | AOD | model input (aerosol/PM proxy) |
| FIRMS | FIRE (T21) | Obj 2 — fire–HCHO link |
| ERA5-Land | T2M, D2M, U10, V10, PRECIP | meteorology; wind = transport |
| CPCB / OpenAQ | pm25, pm10, no2, so2, co, o3 | **labels** (surface truth) |

## Common gotchas

- **Cloudy days have gaps** in NO2/HCHO — that's expected (TROPOMI can't see through
  thick cloud). Keep the masking; handle gaps in Phase 2 (mask token or interpolation).
- **Units**: satellite columns are mol/m². CPCB labels are µg/m³ (CO in mg/m³ for AQI).
  Don't mix them — the model learns the mapping; you only convert CO for the AQI formula.
- **OpenAQ CO** is reported in µg/m³; divide by 1000 → mg/m³ before the CPCB AQI calc.
- If `geemap.ee_export_image` is slow/fails on a day, it's usually an empty collection
  (no overpass). The script catches it and prints `FAIL` — safe to ignore a few.

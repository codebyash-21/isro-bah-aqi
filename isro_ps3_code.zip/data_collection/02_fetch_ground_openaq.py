"""
ISRO BAH 2026 - Problem Statement 3
PHASE 1, STEP 2: Fetch ground-truth surface pollutant concentrations
(CPCB stations, mirrored by OpenAQ) -> these are your TRAINING LABELS.

OpenAQ v3 API. Free API key: https://openaq.org -> account -> API keys.

v2 of this script: adds proper RATE-LIMIT throttling (OpenAQ free tier is
~60 req/min) and a station cap so it finishes in minutes instead of hours.

Output: data/ground_labels.csv
    columns: station_id, station, lat, lon, date, pm25, pm10, no2, so2, co, o3
"""
import requests, time, csv, os
from collections import defaultdict

OPENAQ_KEY   = "your-openaq-api-key"     # <<< EDIT THIS
BBOX  = "68.0,8.0,98.0,37.0"             # India
START = "2024-10-15"
END   = "2024-11-15"
WANT  = {"pm25", "pm10", "no2", "so2", "co", "o3"}

MAX_LOCATIONS = 300      # cap stations (plenty for training; raise later if you like)
MIN_INTERVAL  = 1.1      # seconds between requests -> stays under 60/min

OUT = "data"; os.makedirs(OUT, exist_ok=True)
BASE = "https://api.openaq.org/v3"
HEAD = {"X-API-Key": OPENAQ_KEY}

_last = [0.0]
def _throttle():
    wait = MIN_INTERVAL - (time.time() - _last[0])
    if wait > 0:
        time.sleep(wait)
    _last[0] = time.time()

def get(url, params=None):
    """GET that respects the rate limit and waits out 429s instead of giving up."""
    for attempt in range(8):
        _throttle()
        r = requests.get(url, headers=HEAD, params=params, timeout=60)
        if r.status_code == 429:                       # rate limited
            retry = int(r.headers.get("Retry-After", 0)) or min(60, 5 * (attempt + 1))
            print(f"    rate-limited, waiting {retry}s...")
            time.sleep(retry)
            continue
        r.raise_for_status()
        return r.json()
    r.raise_for_status()

def list_india_locations():
    locs, page = [], 1
    while len(locs) < MAX_LOCATIONS:
        js = get(f"{BASE}/locations", {"bbox": BBOX, "limit": 100, "page": page})
        results = js.get("results", [])
        if not results:
            break
        locs.extend(results)
        if len(results) < 100:
            break
        page += 1
    return locs[:MAX_LOCATIONS]

def daily_for_sensor(sensor_id):
    out, page = [], 1
    while True:
        js = get(f"{BASE}/sensors/{sensor_id}/measurements/daily",
                 {"datetime_from": START, "datetime_to": END, "limit": 1000, "page": page})
        results = js.get("results", [])
        if not results:
            break
        out.extend(results)
        if len(results) < 1000:
            break
        page += 1
    return out

if __name__ == "__main__":
    locations = list_india_locations()
    print(f"Using {len(locations)} OpenAQ locations (cap={MAX_LOCATIONS}).")

    table = defaultdict(dict); meta = {}
    for i, loc in enumerate(locations, 1):
        sid = loc["id"]
        coords = loc.get("coordinates") or {}
        meta[sid] = (loc.get("name", ""), coords.get("latitude"), coords.get("longitude"))
        for sensor in loc.get("sensors", []):
            param = (sensor.get("parameter") or {}).get("name", "").lower()
            if param not in WANT:
                continue
            try:
                for m in daily_for_sensor(sensor["id"]):
                    day = (m.get("period", {}).get("datetimeFrom", {}).get("local", "") or "")[:10]
                    val = m.get("value")
                    if day and val is not None:
                        table[(sid, day)][param] = val
            except Exception as e:
                print("  sensor fail", sensor.get("id"), repr(e)[:60])
        if i % 20 == 0:
            print(f"  ...{i}/{len(locations)} locations  ({len(table)} rows so far)")

    path = os.path.join(OUT, "ground_labels.csv")
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["station_id","station","lat","lon","date","pm25","pm10","no2","so2","co","o3"])
        for (sid, day), vals in sorted(table.items()):
            name, lat, lon = meta[sid]
            w.writerow([sid, name, lat, lon, day] +
                       [vals.get(p, "") for p in ("pm25","pm10","no2","so2","co","o3")])
    print(f"\nWrote {path}  ({len(table)} station-day rows)")

"""
ISRO BAH 2026 - PS3, Phase 1
Use your OWN era5_india_met.nc instead of pulling ERA5 from GEE.

Step A: INSPECT  -> see variables, coords, time range, units.
Step B: ALIGN    -> regrid ERA5 to your satellite grid (or sample at stations).

Needs: pip install xarray netCDF4   (Colab: !pip install xarray netCDF4 -q)
"""
import xarray as xr

NC = "era5_india_met.nc"   # path to your file

# ---------------- STEP A: INSPECT (run this first, paste me the output) -------
ds = xr.open_dataset(NC)
print(ds)                               # full summary
print("\nVARIABLES:", list(ds.data_vars))
print("COORDS    :", list(ds.coords))
for v in ds.data_vars:
    print(f"  {v:12s} units={ds[v].attrs.get('units','?'):12s} shape={ds[v].shape}")

# ERA5 single-levels usually names things:
#   u10, v10, t2m, d2m, blh, tp   with coords latitude/longitude/(valid_)time
# Adjust the names below to whatever STEP A actually prints.

# ---------------- STEP B: ALIGN TO THE SATELLITE GRID -------------------------
# Option 1 - regrid ERA5 onto the same 0.25-deg grid as your GeoTIFFs:
#   target_lat = <from your tif>, target_lon = <from your tif>
#   met_on_grid = ds.interp(latitude=target_lat, longitude=target_lon)
#
# Option 2 - sample ERA5 at each CPCB station (simplest for training table):
#   import pandas as pd
#   stations = pd.read_csv("data/ground_labels.csv")
#   pts = ds.sel(latitude=xr.DataArray(stations.lat, dims="s"),
#                longitude=xr.DataArray(stations.lon, dims="s"),
#                method="nearest")
#   # then select the matching day per row from pts[<var>]
#
# Derived feature you'll want:
#   RH (%) from t2m & d2m (both Kelvin):
#   import numpy as np
#   def rh(t2m, d2m):
#       t, td = t2m-273.15, d2m-273.15
#       es = 6.112*np.exp(17.67*t /(t +243.5))
#       e  = 6.112*np.exp(17.67*td/(td+243.5))
#       return 100.0*e/es
#   wind speed = np.hypot(u10, v10);  wind dir for transport analysis (Obj 2)

"""
ISRO BAH 2026 - PS3, Phase 1, STEP 2 (v3)
Ground-truth labels from the CPCB historical dataset on Kaggle.
(We switched away from OpenAQ because it no longer carries Indian CPCB data.)

Dataset: rohanrao/air-quality-data-in-india  -> city_day.csv (CPCB, 2015-2020)
Window:  align with your satellite data (default Oct-Nov 2019).

SETUP IN COLAB (one time):
    1. kaggle.com -> your profile -> Settings -> "Create New API Token"
       (downloads kaggle.json)
    2. Run, then upload kaggle.json when prompted:

        !pip install kaggle -q
        from google.colab import files; files.upload()      # pick kaggle.json
        !mkdir -p ~/.kaggle && cp kaggle.json ~/.kaggle/ && chmod 600 ~/.kaggle/kaggle.json
        !kaggle datasets download -d rohanrao/air-quality-data-in-india -p data/cpcb --unzip

    3. Then run THIS script.

Output: data/ground_labels.csv
    columns: station_id, station, lat, lon, date, pm25, pm10, no2, so2, co, o3
"""
import pandas as pd, os, unicodedata

CITY_DAY = "data/cpcb/city_day.csv"
START = "2019-10-15"
END   = "2019-11-15"          # inclusive; match your GEE window
OUT   = "data"; os.makedirs(OUT, exist_ok=True)

# CPCB monitoring cities in this dataset -> (lat, lon).
CITY_LATLON = {
    "Ahmedabad": (23.03, 72.58), "Aizawl": (23.73, 92.72), "Amaravati": (16.57, 80.36),
    "Amritsar": (31.63, 74.87), "Bengaluru": (12.97, 77.59), "Bhopal": (23.26, 77.41),
    "Brajrajnagar": (21.82, 83.92), "Chandigarh": (30.73, 76.78), "Chennai": (13.08, 80.27),
    "Coimbatore": (11.02, 76.96), "Delhi": (28.61, 77.21), "Ernakulam": (9.98, 76.28),
    "Gurugram": (28.46, 77.03), "Guwahati": (26.14, 91.74), "Hyderabad": (17.38, 78.49),
    "Jaipur": (26.91, 75.79), "Jorapokhar": (23.71, 86.41), "Kochi": (9.93, 76.27),
    "Kolkata": (22.57, 88.36), "Lucknow": (26.85, 80.95), "Mumbai": (19.08, 72.88),
    "Patna": (25.59, 85.14), "Shillong": (25.58, 91.89), "Talcher": (20.95, 85.23),
    "Thiruvananthapuram": (8.52, 76.94), "Visakhapatnam": (17.69, 83.22),
}

df = pd.read_csv(CITY_DAY)
print("raw columns:", list(df.columns))

# keep our window
df["Date"] = pd.to_datetime(df["Date"])
df = df[(df["Date"] >= START) & (df["Date"] <= END)].copy()

# map dataset columns -> our schema (CPCB CO is already mg/m3)
ren = {"PM2.5": "pm25", "PM10": "pm10", "NO2": "no2",
       "SO2": "so2", "CO": "co", "O3": "o3"}
df = df.rename(columns=ren)

rows = []
for _, r in df.iterrows():
    city = r["City"]
    if city not in CITY_LATLON:
        continue
    lat, lon = CITY_LATLON[city]
    rows.append({
        "station_id": city.lower().replace(" ", "_"),
        "station": city, "lat": lat, "lon": lon,
        "date": r["Date"].date().isoformat(),
        "pm25": r.get("pm25"), "pm10": r.get("pm10"), "no2": r.get("no2"),
        "so2": r.get("so2"), "co": r.get("co"), "o3": r.get("o3"),
    })

out = pd.DataFrame(rows, columns=["station_id","station","lat","lon","date",
                                  "pm25","pm10","no2","so2","co","o3"])
path = os.path.join(OUT, "ground_labels.csv")
out.to_csv(path, index=False)
print(f"\nWrote {path}")
print(f"  {len(out)} city-day label rows, {out['station'].nunique()} cities")
print(out.head(8).to_string(index=False))
